package com.blueocean.googlemap;

public class UserInformasi {

    public double longitude;
    public double latitude;

    public  UserInformasi() {

    }

    public  UserInformasi(double longitude, double latitude) {
        this.longitude=longitude;
        this.latitude=latitude;
    }
}
